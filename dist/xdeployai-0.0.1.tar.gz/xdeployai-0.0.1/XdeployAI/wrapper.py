# wrapper.py
import streamlit.cli

if __name__ == '__main__':
    streamlit.cli._main()