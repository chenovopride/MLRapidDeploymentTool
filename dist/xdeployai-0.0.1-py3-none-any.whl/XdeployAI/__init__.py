#!/usr/bin/env python
# encoding=utf-8
from .st_onnx_cn import main
from .run import webdemo

def test():
    print("测试成功~")

def run_deploy():
    webdemo()